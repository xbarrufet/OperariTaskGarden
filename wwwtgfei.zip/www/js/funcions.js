function slideDiaHasChanged(index) 
{
    alert(index);
}